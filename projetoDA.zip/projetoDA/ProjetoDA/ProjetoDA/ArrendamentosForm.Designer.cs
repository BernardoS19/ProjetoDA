﻿namespace ProjetoDA
{
    partial class ArrendamentosForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ArrendamentosForm));
            this.label1 = new System.Windows.Forms.Label();
            this.lblAid = new System.Windows.Forms.Label();
            this.lblAmorada = new System.Windows.Forms.Label();
            this.lblProprietario = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnRemover = new System.Windows.Forms.Button();
            this.numericUpDownDuracao = new System.Windows.Forms.NumericUpDown();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.checkBoxRenovavel = new System.Windows.Forms.CheckBox();
            this.comboBoxArrendatario = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDuracao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Casa:";
            // 
            // lblAid
            // 
            this.lblAid.AutoSize = true;
            this.lblAid.Location = new System.Drawing.Point(52, 9);
            this.lblAid.Name = "lblAid";
            this.lblAid.Size = new System.Drawing.Size(16, 13);
            this.lblAid.TabIndex = 1;
            this.lblAid.Text = "Id";
            // 
            // lblAmorada
            // 
            this.lblAmorada.AutoSize = true;
            this.lblAmorada.Location = new System.Drawing.Point(52, 33);
            this.lblAmorada.Name = "lblAmorada";
            this.lblAmorada.Size = new System.Drawing.Size(55, 13);
            this.lblAmorada.TabIndex = 2;
            this.lblAmorada.Text = "localidade";
            // 
            // lblProprietario
            // 
            this.lblProprietario.AutoSize = true;
            this.lblProprietario.Location = new System.Drawing.Point(52, 57);
            this.lblProprietario.Name = "lblProprietario";
            this.lblProprietario.Size = new System.Drawing.Size(60, 13);
            this.lblProprietario.TabIndex = 3;
            this.lblProprietario.Text = "Proprietario";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 83);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(274, 264);
            this.listBox1.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(316, 245);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(221, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "Inserir";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnRemover
            // 
            this.btnRemover.Location = new System.Drawing.Point(12, 369);
            this.btnRemover.Name = "btnRemover";
            this.btnRemover.Size = new System.Drawing.Size(274, 23);
            this.btnRemover.TabIndex = 6;
            this.btnRemover.Text = "Remover";
            this.btnRemover.UseVisualStyleBackColor = true;
            // 
            // numericUpDownDuracao
            // 
            this.numericUpDownDuracao.Location = new System.Drawing.Point(316, 156);
            this.numericUpDownDuracao.Name = "numericUpDownDuracao";
            this.numericUpDownDuracao.Size = new System.Drawing.Size(221, 20);
            this.numericUpDownDuracao.TabIndex = 7;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(316, 108);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(221, 20);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // checkBoxRenovavel
            // 
            this.checkBoxRenovavel.AutoSize = true;
            this.checkBoxRenovavel.Location = new System.Drawing.Point(316, 182);
            this.checkBoxRenovavel.Name = "checkBoxRenovavel";
            this.checkBoxRenovavel.Size = new System.Drawing.Size(78, 17);
            this.checkBoxRenovavel.TabIndex = 9;
            this.checkBoxRenovavel.Text = "Renovável";
            this.checkBoxRenovavel.UseVisualStyleBackColor = true;
            // 
            // comboBoxArrendatario
            // 
            this.comboBoxArrendatario.FormattingEnabled = true;
            this.comboBoxArrendatario.Location = new System.Drawing.Point(316, 218);
            this.comboBoxArrendatario.Name = "comboBoxArrendatario";
            this.comboBoxArrendatario.Size = new System.Drawing.Size(221, 21);
            this.comboBoxArrendatario.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(316, 202);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Arrendatário:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(316, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Duração (meses)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(316, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Incio do contrato:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(468, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // ArrendamentosForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(560, 407);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBoxArrendatario);
            this.Controls.Add(this.checkBoxRenovavel);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.numericUpDownDuracao);
            this.Controls.Add(this.btnRemover);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.lblProprietario);
            this.Controls.Add(this.lblAmorada);
            this.Controls.Add(this.lblAid);
            this.Controls.Add(this.label1);
            this.Name = "ArrendamentosForm";
            this.Text = "ArrendamentosForm";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDuracao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblAid;
        private System.Windows.Forms.Label lblAmorada;
        private System.Windows.Forms.Label lblProprietario;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnRemover;
        private System.Windows.Forms.NumericUpDown numericUpDownDuracao;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.CheckBox checkBoxRenovavel;
        private System.Windows.Forms.ComboBox comboBoxArrendatario;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}