﻿namespace ProjetoDA
{
    partial class GerirCasasForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GerirCasasForm));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnNova = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBoxComissaoBase = new System.Windows.Forms.TextBox();
            this.casaCasaVendavelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.projetoDADataSet = new ProjetoDA.ProjetoDADataSet();
            this.textBoxValorBaseNego = new System.Windows.Forms.TextBox();
            this.btnFormVenda = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btnFormArrendar = new System.Windows.Forms.Button();
            this.textBoxComissao = new System.Windows.Forms.TextBox();
            this.casaCasaArrendavelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.textBoxValorBase = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btnGerirLimpezas = new System.Windows.Forms.Button();
            this.checkBoxVendavel = new System.Windows.Forms.CheckBox();
            this.checkBoxArrendavel = new System.Windows.Forms.CheckBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.casaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.numericUpDownPisos = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownWC = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownAssoalhada = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownArea = new System.Windows.Forms.NumericUpDown();
            this.textBoxCasaAndar = new System.Windows.Forms.TextBox();
            this.textBoxCasaNumero = new System.Windows.Forms.TextBox();
            this.textBoxCasaRua = new System.Windows.Forms.TextBox();
            this.textBoxCasaLocalidade = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblidcasa = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.localidadeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ruaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeroDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.andarDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.areaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeroAssoalhadaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeroWCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeroPisosDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnApagar = new System.Windows.Forms.Button();
            this.casaTableAdapter = new ProjetoDA.ProjetoDADataSetTableAdapters.CasaTableAdapter();
            this.casa_CasaArrendavelTableAdapter = new ProjetoDA.ProjetoDADataSetTableAdapters.Casa_CasaArrendavelTableAdapter();
            this.casa_CasaVendavelTableAdapter = new ProjetoDA.ProjetoDADataSetTableAdapters.Casa_CasaVendavelTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.casaCasaVendavelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projetoDADataSet)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.casaCasaArrendavelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.casaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPisos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAssoalhada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownArea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(644, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 60);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnNova);
            this.groupBox1.Controls.Add(this.btnGuardar);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.btnGerirLimpezas);
            this.groupBox1.Controls.Add(this.checkBoxVendavel);
            this.groupBox1.Controls.Add(this.checkBoxArrendavel);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.numericUpDownPisos);
            this.groupBox1.Controls.Add(this.numericUpDownWC);
            this.groupBox1.Controls.Add(this.numericUpDownAssoalhada);
            this.groupBox1.Controls.Add(this.numericUpDownArea);
            this.groupBox1.Controls.Add(this.textBoxCasaAndar);
            this.groupBox1.Controls.Add(this.textBoxCasaNumero);
            this.groupBox1.Controls.Add(this.textBoxCasaRua);
            this.groupBox1.Controls.Add(this.textBoxCasaLocalidade);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.lblidcasa);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(400, 78);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(319, 572);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Detalhes";
            // 
            // btnNova
            // 
            this.btnNova.Location = new System.Drawing.Point(238, 543);
            this.btnNova.Name = "btnNova";
            this.btnNova.Size = new System.Drawing.Size(75, 23);
            this.btnNova.TabIndex = 3;
            this.btnNova.Text = "Nova";
            this.btnNova.UseVisualStyleBackColor = true;
            this.btnNova.Click += new System.EventHandler(this.btnNova_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(6, 543);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 4;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.textBoxComissaoBase);
            this.groupBox3.Controls.Add(this.textBoxValorBaseNego);
            this.groupBox3.Controls.Add(this.btnFormVenda);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Location = new System.Drawing.Point(173, 369);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(146, 130);
            this.groupBox3.TabIndex = 23;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Dados de Venda";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(111, 35);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(13, 13);
            this.label19.TabIndex = 7;
            this.label19.Text = "€";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(109, 76);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(15, 13);
            this.label20.TabIndex = 8;
            this.label20.Text = "%";
            // 
            // textBoxComissaoBase
            // 
            this.textBoxComissaoBase.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.casaCasaVendavelBindingSource, "ValorComissao", true));
            this.textBoxComissaoBase.Location = new System.Drawing.Point(5, 73);
            this.textBoxComissaoBase.Name = "textBoxComissaoBase";
            this.textBoxComissaoBase.Size = new System.Drawing.Size(100, 20);
            this.textBoxComissaoBase.TabIndex = 9;
            // 
            // casaCasaVendavelBindingSource
            // 
            this.casaCasaVendavelBindingSource.DataMember = "Casa_CasaVendavel";
            this.casaCasaVendavelBindingSource.DataSource = this.projetoDADataSet;
            // 
            // projetoDADataSet
            // 
            this.projetoDADataSet.DataSetName = "ProjetoDADataSet";
            this.projetoDADataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // textBoxValorBaseNego
            // 
            this.textBoxValorBaseNego.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.casaCasaVendavelBindingSource, "ValorBaseVenda", true));
            this.textBoxValorBaseNego.Location = new System.Drawing.Point(6, 32);
            this.textBoxValorBaseNego.Name = "textBoxValorBaseNego";
            this.textBoxValorBaseNego.Size = new System.Drawing.Size(100, 20);
            this.textBoxValorBaseNego.TabIndex = 9;
            // 
            // btnFormVenda
            // 
            this.btnFormVenda.Location = new System.Drawing.Point(5, 99);
            this.btnFormVenda.Name = "btnFormVenda";
            this.btnFormVenda.Size = new System.Drawing.Size(100, 23);
            this.btnFormVenda.TabIndex = 9;
            this.btnFormVenda.Text = "Ver";
            this.btnFormVenda.UseVisualStyleBackColor = true;
            this.btnFormVenda.Click += new System.EventHandler(this.btnFormVenda_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 16);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(106, 13);
            this.label17.TabIndex = 2;
            this.label17.Text = "Valor Base Negocial:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 56);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(82, 13);
            this.label18.TabIndex = 3;
            this.label18.Text = "Comissão Base:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.btnFormArrendar);
            this.groupBox2.Controls.Add(this.textBoxComissao);
            this.groupBox2.Controls.Add(this.textBoxValorBase);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Location = new System.Drawing.Point(21, 369);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(146, 130);
            this.groupBox2.TabIndex = 22;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Dados de Arrendamento";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(121, 76);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(15, 13);
            this.label16.TabIndex = 6;
            this.label16.Text = "%";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(121, 36);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(13, 13);
            this.label15.TabIndex = 5;
            this.label15.Text = "€";
            // 
            // btnFormArrendar
            // 
            this.btnFormArrendar.Location = new System.Drawing.Point(15, 99);
            this.btnFormArrendar.Name = "btnFormArrendar";
            this.btnFormArrendar.Size = new System.Drawing.Size(100, 23);
            this.btnFormArrendar.TabIndex = 4;
            this.btnFormArrendar.Text = "Ver/Criar";
            this.btnFormArrendar.UseVisualStyleBackColor = true;
            this.btnFormArrendar.Click += new System.EventHandler(this.btnFormArrendar_Click);
            // 
            // textBoxComissao
            // 
            this.textBoxComissao.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.casaCasaArrendavelBindingSource, "Comissao", true));
            this.textBoxComissao.Location = new System.Drawing.Point(15, 73);
            this.textBoxComissao.Name = "textBoxComissao";
            this.textBoxComissao.Size = new System.Drawing.Size(100, 20);
            this.textBoxComissao.TabIndex = 3;
            // 
            // casaCasaArrendavelBindingSource
            // 
            this.casaCasaArrendavelBindingSource.DataMember = "Casa_CasaArrendavel";
            this.casaCasaArrendavelBindingSource.DataSource = this.projetoDADataSet;
            // 
            // textBoxValorBase
            // 
            this.textBoxValorBase.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.casaCasaArrendavelBindingSource, "ValorBaseMes", true));
            this.textBoxValorBase.Location = new System.Drawing.Point(15, 33);
            this.textBoxValorBase.Name = "textBoxValorBase";
            this.textBoxValorBase.Size = new System.Drawing.Size(100, 20);
            this.textBoxValorBase.TabIndex = 2;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 56);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 13);
            this.label14.TabIndex = 1;
            this.label14.Text = "Comissão:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 16);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "Valor Base (mês):";
            // 
            // btnGerirLimpezas
            // 
            this.btnGerirLimpezas.Location = new System.Drawing.Point(6, 505);
            this.btnGerirLimpezas.Name = "btnGerirLimpezas";
            this.btnGerirLimpezas.Size = new System.Drawing.Size(307, 23);
            this.btnGerirLimpezas.TabIndex = 2;
            this.btnGerirLimpezas.Text = "Gerir Limpezas";
            this.btnGerirLimpezas.UseVisualStyleBackColor = true;
            this.btnGerirLimpezas.Click += new System.EventHandler(this.btnGerirLimpezas_Click);
            // 
            // checkBoxVendavel
            // 
            this.checkBoxVendavel.AutoSize = true;
            this.checkBoxVendavel.Location = new System.Drawing.Point(159, 303);
            this.checkBoxVendavel.Name = "checkBoxVendavel";
            this.checkBoxVendavel.Size = new System.Drawing.Size(71, 17);
            this.checkBoxVendavel.TabIndex = 21;
            this.checkBoxVendavel.Text = "Vendável";
            this.checkBoxVendavel.UseVisualStyleBackColor = true;
            // 
            // checkBoxArrendavel
            // 
            this.checkBoxArrendavel.AutoSize = true;
            this.checkBoxArrendavel.Location = new System.Drawing.Point(73, 303);
            this.checkBoxArrendavel.Name = "checkBoxArrendavel";
            this.checkBoxArrendavel.Size = new System.Drawing.Size(77, 17);
            this.checkBoxArrendavel.TabIndex = 20;
            this.checkBoxArrendavel.Text = "Arrendável";
            this.checkBoxArrendavel.UseVisualStyleBackColor = true;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(73, 276);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 19;
            // 
            // comboBox1
            // 
            this.comboBox1.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.casaBindingSource, "Tipo", true));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(74, 248);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 18;
            // 
            // casaBindingSource
            // 
            this.casaBindingSource.DataMember = "Casa";
            this.casaBindingSource.DataSource = this.projetoDADataSet;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(200, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(22, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "M2";
            // 
            // numericUpDownPisos
            // 
            this.numericUpDownPisos.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.casaBindingSource, "NumeroPisos", true));
            this.numericUpDownPisos.Location = new System.Drawing.Point(74, 221);
            this.numericUpDownPisos.Name = "numericUpDownPisos";
            this.numericUpDownPisos.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownPisos.TabIndex = 16;
            // 
            // numericUpDownWC
            // 
            this.numericUpDownWC.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.casaBindingSource, "NumeroWC", true));
            this.numericUpDownWC.Location = new System.Drawing.Point(74, 195);
            this.numericUpDownWC.Name = "numericUpDownWC";
            this.numericUpDownWC.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownWC.TabIndex = 15;
            // 
            // numericUpDownAssoalhada
            // 
            this.numericUpDownAssoalhada.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.casaBindingSource, "NumeroAssoalhada", true));
            this.numericUpDownAssoalhada.Location = new System.Drawing.Point(74, 169);
            this.numericUpDownAssoalhada.Name = "numericUpDownAssoalhada";
            this.numericUpDownAssoalhada.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownAssoalhada.TabIndex = 14;
            // 
            // numericUpDownArea
            // 
            this.numericUpDownArea.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.casaBindingSource, "Area", true));
            this.numericUpDownArea.Location = new System.Drawing.Point(74, 143);
            this.numericUpDownArea.Name = "numericUpDownArea";
            this.numericUpDownArea.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownArea.TabIndex = 2;
            // 
            // textBoxCasaAndar
            // 
            this.textBoxCasaAndar.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.casaBindingSource, "Andar", true));
            this.textBoxCasaAndar.Location = new System.Drawing.Point(73, 118);
            this.textBoxCasaAndar.Name = "textBoxCasaAndar";
            this.textBoxCasaAndar.Size = new System.Drawing.Size(225, 20);
            this.textBoxCasaAndar.TabIndex = 13;
            // 
            // textBoxCasaNumero
            // 
            this.textBoxCasaNumero.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.casaBindingSource, "Numero", true));
            this.textBoxCasaNumero.Location = new System.Drawing.Point(73, 92);
            this.textBoxCasaNumero.Name = "textBoxCasaNumero";
            this.textBoxCasaNumero.Size = new System.Drawing.Size(225, 20);
            this.textBoxCasaNumero.TabIndex = 12;
            // 
            // textBoxCasaRua
            // 
            this.textBoxCasaRua.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.casaBindingSource, "Rua", true));
            this.textBoxCasaRua.Location = new System.Drawing.Point(73, 66);
            this.textBoxCasaRua.Name = "textBoxCasaRua";
            this.textBoxCasaRua.Size = new System.Drawing.Size(225, 20);
            this.textBoxCasaRua.TabIndex = 11;
            // 
            // textBoxCasaLocalidade
            // 
            this.textBoxCasaLocalidade.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.casaBindingSource, "Localidade", true));
            this.textBoxCasaLocalidade.Location = new System.Drawing.Point(73, 40);
            this.textBoxCasaLocalidade.Name = "textBoxCasaLocalidade";
            this.textBoxCasaLocalidade.Size = new System.Drawing.Size(225, 20);
            this.textBoxCasaLocalidade.TabIndex = 10;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 279);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 13);
            this.label12.TabIndex = 3;
            this.label12.Text = "Porprietário:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 223);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Pisos:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 251);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(31, 13);
            this.label11.TabIndex = 2;
            this.label11.Text = "Tipo:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 197);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "WC\'s:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 171);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Assoalhadas:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 145);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Area:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 121);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Andar:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Numero:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Rua:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Localidade:";
            // 
            // lblidcasa
            // 
            this.lblidcasa.AutoSize = true;
            this.lblidcasa.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.casaBindingSource, "IdCasa", true));
            this.lblidcasa.Location = new System.Drawing.Point(33, 20);
            this.lblidcasa.Name = "lblidcasa";
            this.lblidcasa.Size = new System.Drawing.Size(44, 13);
            this.lblidcasa.TabIndex = 1;
            this.lblidcasa.Text = "ID casa";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.localidadeDataGridViewTextBoxColumn,
            this.ruaDataGridViewTextBoxColumn,
            this.numeroDataGridViewTextBoxColumn,
            this.andarDataGridViewTextBoxColumn,
            this.areaDataGridViewTextBoxColumn,
            this.numeroAssoalhadaDataGridViewTextBoxColumn,
            this.numeroWCDataGridViewTextBoxColumn,
            this.numeroPisosDataGridViewTextBoxColumn,
            this.tipoDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.casaBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 78);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(368, 541);
            this.dataGridView1.TabIndex = 2;
            // 
            // localidadeDataGridViewTextBoxColumn
            // 
            this.localidadeDataGridViewTextBoxColumn.DataPropertyName = "Localidade";
            this.localidadeDataGridViewTextBoxColumn.HeaderText = "Localidade";
            this.localidadeDataGridViewTextBoxColumn.Name = "localidadeDataGridViewTextBoxColumn";
            // 
            // ruaDataGridViewTextBoxColumn
            // 
            this.ruaDataGridViewTextBoxColumn.DataPropertyName = "Rua";
            this.ruaDataGridViewTextBoxColumn.HeaderText = "Rua";
            this.ruaDataGridViewTextBoxColumn.Name = "ruaDataGridViewTextBoxColumn";
            // 
            // numeroDataGridViewTextBoxColumn
            // 
            this.numeroDataGridViewTextBoxColumn.DataPropertyName = "Numero";
            this.numeroDataGridViewTextBoxColumn.HeaderText = "Numero";
            this.numeroDataGridViewTextBoxColumn.Name = "numeroDataGridViewTextBoxColumn";
            // 
            // andarDataGridViewTextBoxColumn
            // 
            this.andarDataGridViewTextBoxColumn.DataPropertyName = "Andar";
            this.andarDataGridViewTextBoxColumn.HeaderText = "Andar";
            this.andarDataGridViewTextBoxColumn.Name = "andarDataGridViewTextBoxColumn";
            // 
            // areaDataGridViewTextBoxColumn
            // 
            this.areaDataGridViewTextBoxColumn.DataPropertyName = "Area";
            this.areaDataGridViewTextBoxColumn.HeaderText = "Area";
            this.areaDataGridViewTextBoxColumn.Name = "areaDataGridViewTextBoxColumn";
            // 
            // numeroAssoalhadaDataGridViewTextBoxColumn
            // 
            this.numeroAssoalhadaDataGridViewTextBoxColumn.DataPropertyName = "NumeroAssoalhada";
            this.numeroAssoalhadaDataGridViewTextBoxColumn.HeaderText = "NumeroAssoalhada";
            this.numeroAssoalhadaDataGridViewTextBoxColumn.Name = "numeroAssoalhadaDataGridViewTextBoxColumn";
            // 
            // numeroWCDataGridViewTextBoxColumn
            // 
            this.numeroWCDataGridViewTextBoxColumn.DataPropertyName = "NumeroWC";
            this.numeroWCDataGridViewTextBoxColumn.HeaderText = "NumeroWC";
            this.numeroWCDataGridViewTextBoxColumn.Name = "numeroWCDataGridViewTextBoxColumn";
            // 
            // numeroPisosDataGridViewTextBoxColumn
            // 
            this.numeroPisosDataGridViewTextBoxColumn.DataPropertyName = "NumeroPisos";
            this.numeroPisosDataGridViewTextBoxColumn.HeaderText = "NumeroPisos";
            this.numeroPisosDataGridViewTextBoxColumn.Name = "numeroPisosDataGridViewTextBoxColumn";
            // 
            // tipoDataGridViewTextBoxColumn
            // 
            this.tipoDataGridViewTextBoxColumn.DataPropertyName = "Tipo";
            this.tipoDataGridViewTextBoxColumn.HeaderText = "Tipo";
            this.tipoDataGridViewTextBoxColumn.Name = "tipoDataGridViewTextBoxColumn";
            // 
            // btnApagar
            // 
            this.btnApagar.Location = new System.Drawing.Point(12, 625);
            this.btnApagar.Name = "btnApagar";
            this.btnApagar.Size = new System.Drawing.Size(368, 23);
            this.btnApagar.TabIndex = 3;
            this.btnApagar.Text = "Apagar";
            this.btnApagar.UseVisualStyleBackColor = true;
            // 
            // casaTableAdapter
            // 
            this.casaTableAdapter.ClearBeforeFill = true;
            // 
            // casa_CasaArrendavelTableAdapter
            // 
            this.casa_CasaArrendavelTableAdapter.ClearBeforeFill = true;
            // 
            // casa_CasaVendavelTableAdapter
            // 
            this.casa_CasaVendavelTableAdapter.ClearBeforeFill = true;
            // 
            // GerirCasasForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(731, 662);
            this.Controls.Add(this.btnApagar);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "GerirCasasForm";
            this.Text = "GerirCasasForm";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.casaCasaVendavelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projetoDADataSet)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.casaCasaArrendavelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.casaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPisos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAssoalhada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownArea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblidcasa;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnFormArrendar;
        private System.Windows.Forms.TextBox textBoxComissao;
        private System.Windows.Forms.TextBox textBoxValorBase;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.CheckBox checkBoxVendavel;
        private System.Windows.Forms.CheckBox checkBoxArrendavel;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numericUpDownPisos;
        private System.Windows.Forms.NumericUpDown numericUpDownWC;
        private System.Windows.Forms.NumericUpDown numericUpDownAssoalhada;
        private System.Windows.Forms.NumericUpDown numericUpDownArea;
        private System.Windows.Forms.TextBox textBoxCasaAndar;
        private System.Windows.Forms.TextBox textBoxCasaNumero;
        private System.Windows.Forms.TextBox textBoxCasaRua;
        private System.Windows.Forms.TextBox textBoxCasaLocalidade;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnNova;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.TextBox textBoxComissaoBase;
        private System.Windows.Forms.TextBox textBoxValorBaseNego;
        private System.Windows.Forms.Button btnFormVenda;
        private System.Windows.Forms.Button btnGerirLimpezas;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnApagar;
        private ProjetoDADataSet projetoDADataSet;
        private System.Windows.Forms.BindingSource casaBindingSource;
        private ProjetoDADataSetTableAdapters.CasaTableAdapter casaTableAdapter;
        private System.Windows.Forms.BindingSource casaCasaArrendavelBindingSource;
        private ProjetoDADataSetTableAdapters.Casa_CasaArrendavelTableAdapter casa_CasaArrendavelTableAdapter;
        private System.Windows.Forms.BindingSource casaCasaVendavelBindingSource;
        private ProjetoDADataSetTableAdapters.Casa_CasaVendavelTableAdapter casa_CasaVendavelTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn localidadeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ruaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn andarDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn areaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroAssoalhadaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroWCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroPisosDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoDataGridViewTextBoxColumn;
    }
}